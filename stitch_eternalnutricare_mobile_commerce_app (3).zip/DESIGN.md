---
name: Organic Vitality System
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#42493c'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#72796b'
  outline-variant: '#c2c9b8'
  surface-tint: '#3a6a1f'
  primary: '#336318'
  on-primary: '#ffffff'
  primary-container: '#4b7c2f'
  on-primary-container: '#deffc5'
  inverse-primary: '#9fd67d'
  secondary: '#745853'
  on-secondary: '#ffffff'
  secondary-container: '#fed7d0'
  on-secondary-container: '#795c57'
  tertiary: '#585854'
  on-tertiary: '#ffffff'
  tertiary-container: '#70706c'
  on-tertiary-container: '#f7f5f0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#baf296'
  primary-fixed-dim: '#9fd67d'
  on-primary-fixed: '#082100'
  on-primary-fixed-variant: '#235106'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#e3beb8'
  on-secondary-fixed: '#2b1613'
  on-secondary-fixed-variant: '#5b403c'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: DM Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: DM Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: DM Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-sm:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-uppercase:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  price-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 20px
  gutter-grid: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  section-gap: 40px
---

## Brand & Style

The design system is rooted in the philosophy of "Premium Purity." It serves a health-conscious, discerning audience that values transparency and the artisanal quality of natural foods. The UI evokes a sense of calm, trustworthiness, and effortless luxury through a blend of **Modern Minimalism** and **Tactile warmth**.

The visual narrative relies on high-fidelity, realistic product photography set against expansive, clean backgrounds. The emotional response is one of "freshness from the earth," achieved by combining professional commerce structures with soft, organic geometry.

**Key Stylistic Pillars:**
- **Organic Geometry:** Utilizing generous border radii to mimic the soft curves found in nature.
- **Editorial Clarity:** Strong typographic hierarchy that prioritizes readability and brand authority.
- **Natural Tactility:** Subtle depth through soft shadows, making digital products feel physically present and "shoppable."

## Colors

The palette is derived from a natural landscape, emphasizing earthiness and growth.

- **Primary (Forest Green):** #4B7C2F. Used for action buttons, success states, and brand-defining accents. It symbolizes health and vitality.
- **Secondary (Earth Brown):** #3E2723. Used for primary typography and deep-contrast elements. This replaces standard black to maintain a softer, organic feel.
- **Tertiary (Warm Cream):** #F9F7F2. The foundational background color for cards and container sections to provide a premium, paper-like warmth.
- **Neutral (Cloud White):** #FFFFFF. Used for the primary app background and high-lighting surfaces to maintain a sense of cleanliness.
- **Supportive Accents:** Light greens and subtle ambers may be used in photography or specific labels to denote flavor profiles or organic certifications.

## Typography

This design system utilizes **DM Sans** for its geometric yet approachable character, providing a modern "DTC" (Direct-to-Consumer) aesthetic. **Plus Jakarta Sans** is used sparingly for labels and utility text to add a touch of friendly sophistication.

**Usage Guidelines:**
- **Hierarchy:** Headlines should always use the deep Earth Brown (#3E2723) to ensure a grounded, authoritative presence.
- **Readability:** Maintain generous line heights for body text to ensure descriptions of ingredients and benefits are easily digestible.
- **Price Styling:** Prices should be prominent but integrated, using a bold weight in the primary Earth Brown color.

## Layout & Spacing

The layout follows a **Fluid Grid** model optimized for mobile commerce, ensuring that product imagery remains the focal point across various device widths.

- **Mobile Grid:** A 2-column or 4-column system for product listings.
- **Margins:** A consistent 20px horizontal margin ensures content doesn't feel cramped against the screen edges.
- **Sectioning:** Use large 40px gaps between major sections (e.g., between Hero and Categories) to create a relaxed, premium pace for the user journey.
- **White Space:** Prioritize whitespace over borders. Containers should breathe, allowing the high-quality product photography to "own" the space.

## Elevation & Depth

Depth is used to simulate a physical retail environment where products sit on clean surfaces.

- **Tonal Layering:** The primary method of hierarchy. Use the Warm Cream (#F9F7F2) for cards and sections against the pure White background.
- **Product Shadows:** Use "Natural Ambient" shadows for cards—very soft, highly diffused (Blur: 20px-30px, Opacity: 4-6%) with a slight brown tint to match the typography, rather than neutral grey.
- **Interaction Depth:** Buttons and active cards may use a slightly deeper shadow on press to provide tactile feedback, mimicking the "squish" of a premium organic package.

## Shapes

The shape language is "Premium Rounded." Sharp corners are avoided to maintain a friendly, natural aesthetic.

- **Primary Cards:** Use a minimum of 16px (rounded-lg) for product cards and banners.
- **Buttons:** Fully rounded (pill-shaped) or 12px depending on the prominence.
- **Input Fields:** 12px radius to match the overall soft-geometric language.
- **Icon Containers:** Circular or highly rounded containers for category icons to emphasize the organic theme.

## Components

### Buttons
- **Primary:** Forest Green background, White text. Pill-shaped.
- **Secondary/Ghost:** Earth Brown outline or text-only for less critical actions.
- **Icon Buttons:** Use for "Add to Cart" (+) inside product cards, typically a small circular or square button with 8px radius and Primary Green styling.

### Cards
- **Product Card:** Warm Cream background, 16px radius. Contains a high-res image, title, weight/description, price, and a quick-add action. 
- **Banner Card:** Uses full-bleed imagery with Earth Brown or Forest Green text overlays. Ensure high contrast for legibility.

### Input Fields
- **Search Bar:** Light Grey (#F2F2F2) or White with a subtle 1px border. 12px radius. Internal icons in Earth Brown.

### Navigation
- **Bottom Bar:** White background with a subtle top shadow. Icons transition from grey to Forest Green when active. Label text uses `label-uppercase` style.
- **Category Chips:** Circular image containers with Earth Brown labels underneath.

### Selection Controls
- **Checkboxes/Radio:** Use the Forest Green primary color. Use rounded corners for checkboxes to stay consistent with the brand's shape language.